chrome.runtime.onInstalled.addListener(function () {
	// コンテキストメニューの追加
	const parent = chrome.contextMenus.create({
		title: "選択文字列をパスとして開く",
		type: "normal",
		id: "normal1",
		contexts: ["selection"]
	});
	console.log("Context Menu created.");
});

chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		editPath(request.type, request.text);
		sendResponse({ response: "listeher is successful" });
	}
);

/**
  * メニューが選択されたときの処理
  * 選択されたアイテムはこちらの関数の引数に入ってくる(今回は item)
  */
chrome.contextMenus.onClicked.addListener(function (item) {
	console.log(item.selectionText);
	editPath("strpath", item.selectionText);
});

function editPath(str, text) {
	switch (str) {
		case "strpath":
			var copytext = ""
			copytext = text;
			console.log(copytext);
			copytext = copytext.replace(/%%/g, '%25%') // 23/08/01 追加 パスに%が入っていた時の処理
			copytext = copytext.replace(/%20/g, ' ')
			console.log("%と空白を処理:" + copytext);
			// 24/11/08 サーバ名をトリガーにするよう変更
			// var index = copytext.indexOf("href=\"");
			var serverPath = "SD123456789";
			var index = copytext.indexOf(`\\\\${serverPath}`);
			if (index != -1) {
			// 	copytext = copytext.slice(index + 6);
				copytext = copytext.slice(index);
				// console.log("href削除:" + copytext);
				console.log("前半不要部分削除:" + copytext);
			} else {
				var index = copytext.indexOf(`file://${serverPath}`);
				if (index != -1) {
				// 	copytext = copytext.slice(index + 6);
					copytext = copytext.slice(index);
					// console.log("href削除:" + copytext);
					console.log("前半不要部分削除:" + copytext);
				} 
			}

			index = copytext.indexOf("<");
			if (index != -1) {
				copytext = copytext.substring(0, index)
				console.log("<より後ろを削除:" + copytext);
			}
			index = copytext.indexOf("\"");
			if (index != -1) {
				copytext = copytext.substring(0, index);
				console.log("\"より後ろを削除:" + copytext);
			}
			// 24/11/08 順番変更
			if ((copytext.match(/%/g) || []).length > 1) { // 24/11/08 4⇒1に変更
				copytext = decodeURIComponent(copytext)
				console.log("文字コード変換:" + copytext);
			}
			// 文字列にfile://を追加
			// httpsから始まるときは追加しない
			if ((copytext.indexOf(("https://")) == -1) && (copytext.indexOf(("file://")) == -1)) {
				copytext = "file://" + copytext;
				console.log("file://を追加:" + copytext);
			}
			// &amp;を置換
			copytext = copytext.replace(/&amp;/g, "&")
			console.log("&を変換:" + copytext);

			var send_message = copytext;

			var start_time = Date.now();

			chrome.runtime.sendNativeMessage("open_local_file", { "data": send_message }, function () {
				var end_time = Date.now();
				console.log(end_time - start_time);
			})
			break;
		default:
			console.log("Error: Unkown request.");
	}
}
