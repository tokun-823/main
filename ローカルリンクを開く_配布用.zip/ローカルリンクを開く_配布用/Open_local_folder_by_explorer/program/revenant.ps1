try {
    
    $reader = New-Object System.IO.BinaryReader([System.Console]::OpenStandardInput())
    $len = $reader.ReadInt32()
    $buf = $reader.ReadBytes($len)
    New-Item -path . -ItemType "file" -Name "buf.txt" -Value "$buf"
    Out-File -InputObject $buf -FilePath .\buf.txt
    $msg = [System.Text.Encoding]::UTF8.GetString($buf)

    $obj = $msg | ConvertFrom-Json

    New-Item -path . -ItemType "file" -Name "obj.txt" -Value "$obj"
    Out-File -InputObject $obj -FilePath .\obj.txt
    $url = $obj.data.Remove(0, 5) # 引数をURLに指定
    if ($url.IndexOf("/////") -ne -1) {
        $url = $url.Remove(0, 3)
    }
    elseif ($url.IndexOf("////") -ne -1) {
        $url = $url.Remove(0, 2)
    }
    elseif ($url.IndexOf("///") -ne -1) {
        $url = $url.Remove(0, 3)
    }
    elseif ($url.IndexOf("//\\") -ne -1) {
        $url = $url.Remove(0, 2)
    }
    # $url = "'" + $url + "'"
    Out-File -InputObject $url -FilePath .\url.txt
    Invoke-Item -LiteralPath $url
    # 略
}
catch {
    $error[0] | Format-List -force | Out-File "error.log"
}