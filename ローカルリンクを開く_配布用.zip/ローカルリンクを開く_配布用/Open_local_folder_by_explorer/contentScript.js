console.log("load content script");

window.addEventListener(
  "click",
  function (e) {
    console.log(document.body);
    // e.target: イベント発生源
    pickedEl = e.target;
    console.log(pickedEl.outerHTML);
    counter = 0;

    // input要素かつreadonly属性がない場合は処理を中断
    if (
      pickedEl.tagName.toLowerCase() === "input" &&
      !pickedEl.hasAttribute("readonly")
    ) {
      console.log("Non-readonly input element clicked, processing stopped.");
      return;
    }
    // 追加 異様に大きな要素の場合は処理を実行しない
    if (pickedEl.outerHTML.length >= 5000) {
      console.log(pickedEl.outerHTML.length);
      return;
    }
    // 親階層を順にみてリンク部分を探す
    while (
      // (pickedEl.outerHTML.indexOf('<a href="file') == -1 &&
      // pickedEl.outerHTML.indexOf('<a href="\\\\') == -1) ||
      pickedEl.outerHTML.indexOf("SD123456789") == -1 ||
      counter >= 15
    ) {
      // 何も指定しないとどのページでも読み込むので、文字数制限を設け超えた場合はループを抜ける
      if (pickedEl.outerHTML.length >= 5000) {
        console.log(pickedEl.outerHTML.length);
        return;
      }
      pickedEl = pickedEl.parentElement;
      console.log(pickedEl.outerHTML);
      counter += 1;
    }
    chrome.runtime.sendMessage({
      type: "strpath",
      text: pickedEl.outerHTML,
    });
  },
  false
);
